package com.robosoft.lorem.entity;

import lombok.Data;

@Data
public class Addon {

    private int addOnId;
    private String addon;
    private float price;
}
