package com.prajwal.hospital.service;

import com.prajwal.hospital.model.Insurance;

public interface UserService {

    //insure an user
    Insurance insureUser(Insurance insurance);
}
