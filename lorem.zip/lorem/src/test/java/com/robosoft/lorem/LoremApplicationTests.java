package com.robosoft.lorem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoremApplicationTests {

	@Test
	void contextLoads() {
	}

}
