package com.robosoft.lorem.model;

import lombok.Data;

import java.util.List;

@Data
public class NearByBrandsSearchResult {

    private int resultsCount;
    private List<BrandSearchModel> nearByBrands;
}
