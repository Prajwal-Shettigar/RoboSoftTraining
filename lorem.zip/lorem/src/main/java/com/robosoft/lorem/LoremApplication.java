package com.robosoft.lorem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoremApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoremApplication.class, args);
	}

}
