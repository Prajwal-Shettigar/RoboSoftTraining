package com.robosoft.lorem.service;

import com.robosoft.lorem.routeResponse.Location;
import com.robosoft.lorem.routeResponse.Root;

public interface LocationService {



    //get distance required to travel from start to end
    double getDistance(Location start,Location end);


    //get time required to travel from start to end
    double getDuration(Location start,Location end);
}
