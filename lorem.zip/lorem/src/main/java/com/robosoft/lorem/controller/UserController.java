package com.robosoft.lorem.controller;


import com.robosoft.lorem.model.*;
import com.robosoft.lorem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {


    @Autowired
    UserService userService;


    //search with filter
    @GetMapping("/Search")
    public RestaurantSearchResult getRest(@RequestBody SearchFilter searchFilter) {
        return userService.searchRestaurant(searchFilter);
    }

    //get all restaurants


    //get nearby brands
    @GetMapping("/Brands/{address}/{limit}")
    public NearByBrandsSearchResult getNearByBrands(@PathVariable String address, @PathVariable int limit){
        return userService.getNearbyBrands(address,limit);
    }


    //create and update cart
    @PostMapping("/Cart")
    public CartModel createOrUpdateCart(@RequestBody CartModel cartModel){
        return userService.saveOrUpdateCart(cartModel);
    }




}
