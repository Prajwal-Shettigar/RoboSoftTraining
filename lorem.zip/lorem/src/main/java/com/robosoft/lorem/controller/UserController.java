package com.robosoft.lorem.controller;


import com.robosoft.lorem.model.RestaurantSearchModel;
import com.robosoft.lorem.model.SearchFilter;
import com.robosoft.lorem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController {


    @Autowired
    UserService userService;

    @GetMapping("/Search")
    public List<RestaurantSearchModel> getRest(@RequestBody SearchFilter searchFilter) {
        return userService.searchRestaurant(searchFilter);
    }

    //get all restaurants


    //get nearby restaurants




}
