package com.robosoft.lorem.controller;


import com.robosoft.lorem.model.*;
import com.robosoft.lorem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    UserService userService;


    //search with filter
    @GetMapping("/Search")
    public RestaurantSearchResult getRest(@RequestBody SearchFilter searchFilter) {
        return userService.searchRestaurant(searchFilter);
    }



    //get nearby brands
    @GetMapping("/Brands/{address}/{limit}")
    public NearByBrandsSearchResult getNearByBrands(@PathVariable String address, @PathVariable int limit){
        return userService.getNearbyBrands(address,limit);
    }


    //create and update cart
    @PostMapping("/Cart")
    public CartModel createOrUpdateCart(@RequestBody CartModel cartModel){
        return userService.saveOrUpdateCart(cartModel);
    }


    //like and unlike review
    @PostMapping("/Review/Like/{reviewId}/{userId}")
    public ResponseEntity<?> likeAReview(@PathVariable int reviewId, @PathVariable int userId){
        if(userService.likeAreview(userId,reviewId))
            return new ResponseEntity<>("Liked Review Successfully...",HttpStatus.OK);

        return new ResponseEntity<>("UnLiked Review Successfully...",HttpStatus.EXPECTATION_FAILED);
    }


    //get My Profile
    @GetMapping("/Profile/{userId}")
    public ResponseEntity<?> getUserProfile(@PathVariable int userId){
        UserProfile userProfile = userService.getUserProfile(userId);

        if(userProfile!=null)
            return new ResponseEntity<>(userProfile,HttpStatus.OK);

        return new ResponseEntity<>(userProfile,HttpStatus.NO_CONTENT);
    }


    //get my orders based on status
    @GetMapping("/Orders/{orderStatus}/{pageNumber}/{userId}")
    public OrderResponseModel getMyOrdersByStatus(@PathVariable String orderStatus,@PathVariable int pageNumber,@PathVariable int userId){
            return userService.getMyOrdersByStatus(orderStatus,userId,pageNumber);
    }





}
