package com.robosoft.lorem.service;

import com.robosoft.lorem.model.RestaurantSearchModel;
import com.robosoft.lorem.model.SearchFilter;
import com.robosoft.lorem.routeResponse.Location;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;


@Service
public class UserServiceImpl implements UserService{

    @Autowired
    LocationService locationService;

    @Autowired
    JdbcTemplate jdbcTemplate;

    String query;

    private static final int perPageDataCount = 10;


    @Override
    public List<RestaurantSearchModel> searchRestaurant(SearchFilter searchFilter) {

        long offset = this.getOffset(searchFilter.getPageNumber());


        if(searchFilter.getRestaurantOrFoodType()==null)
            searchFilter.setRestaurantOrFoodType("");


        query = "SELECT distinct " +
                "r.restaurantId," +
                "r.restaurantName," +
                "r.overAllRating," +
                "r.minimumCost," +
                "r.addressId," +
                "r.profilePic," +
                "r.workingHours," +
                "r.cardAccepted," +
                "r.Description," +
                "r.restaurantType," +
                "r.brandId," +
                "r.userId," +
                "a.longitude," +
                "a.lattitude," +
                "o.openingTime," +
                "o.closingTime," +
                "opened," +
                "a.addressDesc " +
                "FROM restaurant r " +
                "inner join menu m " +
                "on r.restaurantId=m.restaurantId " +
                "inner join address a " +
                "on r.addressId=a.addressId " +
                "inner join openinginfo o " +
                "on r.restaurantId=o.restaurantId " +
                "where (r.restaurantName like '%"+searchFilter.getRestaurantOrFoodType()+"%' " +
                "or " +
                "m.foodType like '%"+searchFilter.getRestaurantOrFoodType()+"%') " +
                "and " +
                "o.dateOf='"+searchFilter.getDate()+"' " +
                "and a.addressDesc like '%"+searchFilter.getAddress()+"%' "+
                "limit "+offset+","+perPageDataCount;


        ;

        return jdbcTemplate.query(query,(rs,noOfROws)->{

            RestaurantSearchModel restaurantSearchModel = new RestaurantSearchModel();
            restaurantSearchModel.setRestaurantId(rs.getInt(1));
            restaurantSearchModel.setRestaurantName(rs.getString(2));
            restaurantSearchModel.setOverAllRating(rs.getInt(3));
            restaurantSearchModel.setMinimumCost(rs.getDouble(4));
            restaurantSearchModel.setAddressId(rs.getInt(5));
            restaurantSearchModel.setProfilePic(rs.getString(6));
            restaurantSearchModel.setWorkingHours(rs.getString(7));
            restaurantSearchModel.setCardAccepted(rs.getBoolean(8));
            restaurantSearchModel.setDescription(rs.getString(9));
            restaurantSearchModel.setRestaurantType(rs.getString(10));
            restaurantSearchModel.setBrandId(rs.getInt(11));
            restaurantSearchModel.setUserId(rs.getInt(12));

            Location restaurantLocation = new Location(rs.getDouble(13), rs.getDouble(14));

            restaurantSearchModel.setLocation(restaurantLocation);
            restaurantSearchModel.setOpeningTime(rs.getString(15));
            restaurantSearchModel.setClosingTime(rs.getString(16));
            restaurantSearchModel.setOpened(rs.getBoolean(17));
            restaurantSearchModel.setAvgMealCost(this.getAverageMealCostForRestaurant(restaurantSearchModel.getRestaurantId()));
            restaurantSearchModel.setDeliveryTime(locationService.getDuration(searchFilter.getLocation(),restaurantLocation));
            restaurantSearchModel.setAddressDesc(rs.getString(18));

            return restaurantSearchModel;
        });
    }


    public double getAverageMealCostForRestaurant(int restaurantId){
        return jdbcTemplate.queryForObject("select avg(price) from menu where restaurantId="+restaurantId, Double.class);
    }

    public long getOffset(int pageNumber){
        return (long)perPageDataCount*(pageNumber-1);
    }
}
