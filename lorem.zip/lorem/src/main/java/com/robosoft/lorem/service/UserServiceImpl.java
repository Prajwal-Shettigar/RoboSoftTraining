package com.robosoft.lorem.service;

import com.robosoft.lorem.model.*;
import com.robosoft.lorem.routeResponse.Location;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserServiceImpl implements UserService{

    @Autowired
    LocationService locationService;

    @Autowired
    JdbcTemplate jdbcTemplate;



    private static final int perPageDataCount=10;

    String query;


    @Override
    public RestaurantSearchResult searchRestaurant(SearchFilter searchFilter) {


        RestaurantSearchResult restaurantSearchResult = new RestaurantSearchResult();

        long offset = this.getOffset(searchFilter.getPageNumber());


        if(searchFilter.getRestaurantOrFoodType()==null)
            searchFilter.setRestaurantOrFoodType("");


        String selectFields = "SELECT distinct " +
                "r.restaurantId," +
                "r.restaurantName," +
                "r.overAllRating," +
                "r.minimumCost," +
                "r.addressId," +
                "r.profilePic," +
                "r.workingHours," +
                "r.cardAccepted," +
                "r.Description," +
                "r.restaurantType," +
                "r.brandId," +
                "r.userId," +
                "a.longitude," +
                "a.lattitude," +
                "o.openingTime," +
                "o.closingTime," +
                "opened," +
                "r.averageCost,"+
                "a.addressDesc,"+
                "r.averageDeliveryTime ";


        query = "FROM restaurant r " +
                "inner join menu m " +
                "on r.restaurantId=m.restaurantId " +
                "inner join address a " +
                "on r.addressId=a.addressId " +
                "inner join openinginfo o " +
                "on r.restaurantId=o.restaurantId " +
                "where (r.restaurantName like '%"+searchFilter.getRestaurantOrFoodType()+"%' " +
                "or " +
                "m.foodType like '%"+searchFilter.getRestaurantOrFoodType()+"%') " +
                "and " +
                "o.dateOf='"+searchFilter.getDate()+"' " +
                "and a.addressDesc like '%"+searchFilter.getAddress()+"%' ";






        if(searchFilter.isOpenNow())
            query = query+"and o.opened=true ";

        if(searchFilter.getMaxAvgMealCost()>0)
            query=query+"and r.averageCost<="+searchFilter.getMaxAvgMealCost()+" ";

        if(searchFilter.getMaxMinOrderCost()>0)
            query = query+"and r.minimumCost<="+searchFilter.getMaxMinOrderCost()+" ";

        if(searchFilter.getCuisineType()!=null)
            query= query+" and r.restaurantType like '%"+searchFilter.getCuisineType()+"%' ";

        if(searchFilter.getDeliveryTime()!=0)
            query=query+" and r.averageDeliveryTime<="+searchFilter.getDeliveryTime()+" ";

        if(!searchFilter.isDescRating())
            query=query+" order by r.overAllRating asc ";
        else
            query=query+" order by r.overAllRating desc ";


        if(searchFilter.getPageNumber()==1){
            String countQuery = "SELECT count(distinct r.restaurantId) ";
            restaurantSearchResult.setTotalRocordsCount(jdbcTemplate.queryForObject(countQuery+query, Long.class));
        }




        query = selectFields+query+"limit "+offset+","+perPageDataCount;

        List<RestaurantSearchModel> restaurants =  jdbcTemplate.query(query,(rs,noOfROws)->{

            RestaurantSearchModel restaurantSearchModel = new RestaurantSearchModel();
            restaurantSearchModel.setRestaurantId(rs.getInt(1));
            restaurantSearchModel.setRestaurantName(rs.getString(2));
            restaurantSearchModel.setOverAllRating(rs.getDouble(3));
            restaurantSearchModel.setMinimumCost(rs.getDouble(4));
            restaurantSearchModel.setAddressId(rs.getInt(5));
            restaurantSearchModel.setProfilePic(rs.getString(6));
            restaurantSearchModel.setWorkingHours(rs.getString(7));
            restaurantSearchModel.setCardAccepted(rs.getBoolean(8));
            restaurantSearchModel.setDescription(rs.getString(9));
            restaurantSearchModel.setRestaurantType(rs.getString(10));
            restaurantSearchModel.setBrandId(rs.getInt(11));
            restaurantSearchModel.setUserId(rs.getInt(12));

            Location restaurantLocation = new Location(rs.getDouble(13), rs.getDouble(14));

            restaurantSearchModel.setLocation(restaurantLocation);
            restaurantSearchModel.setOpeningTime(rs.getString(15));
            restaurantSearchModel.setClosingTime(rs.getString(16));
            restaurantSearchModel.setOpened(rs.getBoolean(17));
            restaurantSearchModel.setAvgMealCost(rs.getDouble(18));
            restaurantSearchModel.setDeliveryTime(locationService.getDuration(searchFilter.getLocation(),restaurantLocation));
            restaurantSearchModel.setAddressDesc(rs.getString(19));
            restaurantSearchModel.setAverageDeliveryTime(rs.getDouble(20));

            return restaurantSearchModel;
        });

        restaurantSearchResult.setPerPageRecordsCount(restaurants.size());

        restaurantSearchResult.setPageResults(restaurants);

        return restaurantSearchResult;
    }


    public double getAverageMealCostForRestaurant(int restaurantId){
        return jdbcTemplate.queryForObject("select avg(price) from menu where restaurantId="+restaurantId, Double.class);
    }

    public long getOffset(int pageNumber){
        return (long)perPageDataCount*(pageNumber-1);
    }



    @Override
    public NearByBrandsSearchResult getNearbyBrands(String address, int limit){
        query="select distinct b.brandId,b.brandName,b.description,b.logo,b.profilePic,b.brandOrigin from brand b inner join restaurant r on b.brandId=r.brandId inner join address a on r.addressId=a.addressId where addressDesc like '%"+address+"%' limit "+limit;


        NearByBrandsSearchResult nearByBrandsSearchResult = new NearByBrandsSearchResult();


        List<BrandSearchModel> nearByBrands =  jdbcTemplate.query(query,(rs, noOfRows)->{
            BrandSearchModel brandSearchModel = new BrandSearchModel();
            brandSearchModel.setBrandId(rs.getInt(1));
            brandSearchModel.setBrandName(rs.getString(2));
            brandSearchModel.setDescription(rs.getString(3));
            brandSearchModel.setLogo(rs.getString(4));
            brandSearchModel.setProfilePic(rs.getString(5));
            brandSearchModel.setBrandOrigin(rs.getString(6));

            return brandSearchModel;
        });

        nearByBrandsSearchResult.setResultsCount(nearByBrands.size());
        nearByBrandsSearchResult.setNearByBrands(nearByBrands);

        return nearByBrandsSearchResult;
    }

    @Override
    public CartModel saveOrUpdateCart(CartModel cartModel) {
        //check if cart is an existing cart then delete its items

        int cartId;


        //if update operation
        if(cartModel.getCartId()!=null){
            this.deleteCartItems(cartModel.getCartId());
            cartId = this.updateCart(cartModel);
        }
        //if it's a new cart then create it in the database and get the id
        else {
            cartId = this.createCart(cartModel);
        }
        //add items of cart into item table
        query = "insert into item(dishId,cartId,addOnCount,count,customizable) values(?,?,?,?,?)";
        for(ItemModel item:cartModel.getItemsIncart()){
            this.addItemIntoCart(item,cartId,query);
        }

        cartModel.setCartId(cartId);

        return cartModel;

    }

    //add item into item table
    public boolean addItemIntoCart(ItemModel itemModel,int cartId,String query){
        jdbcTemplate.update(query,(preparedStatement)->{
            preparedStatement.setInt(1,itemModel.getDishId());
            preparedStatement.setInt(2,cartId);
            preparedStatement.setInt(3,itemModel.getAddOnCount());
            preparedStatement.setInt(4,itemModel.getItemCount());
            preparedStatement.setString(5,itemModel.getCustomizationInfo());
        });

        return true;
    }



    //delete all items from cart
    public boolean deleteCartItems(int cartId){
        query = "delete from item where cartId="+cartId;

        jdbcTemplate.update(query);

        return true;

    }

    //create a cart in the db using userId and fetch cart id
    public int createCart(CartModel cartModel){
        query = "insert into cart(userId,cookingInstructions,scheduledDate,scheduledTime,totalAmount,restaurantId) values(?,?,?,?,?,?)";

        jdbcTemplate.update(query,(preparedStatement)->{
            preparedStatement.setInt(1,cartModel.getUserId());
            preparedStatement.setString(2, cartModel.getCookingInstruction());
            preparedStatement.setDate(3,cartModel.getScheduleDate());
            preparedStatement.setTime(4,cartModel.getScheduleTime());
            preparedStatement.setDouble(5,cartModel.getToPay());
            preparedStatement.setInt(6,cartModel.getRestaurantId());
        });
        query = "select max(cartId) from cart where userId="+cartModel.getUserId();

        return jdbcTemplate.queryForObject(query,Integer.class);
    }


    //update a cart in the db
    public int updateCart(CartModel cartModel){
        query = "update cart set cookingInstructions='"+cartModel.getCookingInstruction()+"',totalAmount="+cartModel.getToPay()+" where cartId="+cartModel.getCartId();

        jdbcTemplate.update(query);

        return cartModel.getCartId();
    }


    //like or unlike a review

    @Override
    public boolean likeAreview(int userId, int reviewId) {
        query = "insert into likes values("+userId+","+reviewId+")";

        try{
            jdbcTemplate.update(query);
        }catch(DuplicateKeyException exception){
            query = "delete from likes where userID="+userId+" and reviewId="+reviewId;

            jdbcTemplate.update(query);

            query = "update review set likeCount=likeCount-1 where reviewId="+reviewId;

            return false;
        }

        query = "update review set likeCount=likeCount+1 where reviewId="+reviewId;

        jdbcTemplate.update(query);

        return true;
    }


    //get user profile using userId

    @Override
    public UserProfile getUserProfile(int userId) {
        query = "select userId,firstName,lastName,emailId,mobileNo,profilePic,creditScore from user where userId="+userId;

        UserProfile userProfile = jdbcTemplate.queryForObject(query,(rs,noOfRows)->{
            UserProfile returningUserProfile = new UserProfile();


            returningUserProfile.setUserId(rs.getInt(1));
            returningUserProfile.setFirstName(rs.getString(2));
            returningUserProfile.setLastName(rs.getString(3));
            returningUserProfile.setEmail(rs.getString(4));
            returningUserProfile.setMobileNumber(rs.getString(5));
            returningUserProfile.setProfilePicURL(rs.getString(6));
            returningUserProfile.setCreditScore(rs.getInt(7));


            return returningUserProfile;
        });


        if(userProfile.getMobileNumber()!=null){
            query = "select otpVerified from mobileotp where mobileNo="+userProfile.getMobileNumber();

            userProfile.setMobileVerified(jdbcTemplate.queryForObject(query, Boolean.class));
        }

        return userProfile;

    }
}
