package com.robosoft.lorem.service;

public interface AdminService {

    boolean changeRole(int userId,String role);
}
