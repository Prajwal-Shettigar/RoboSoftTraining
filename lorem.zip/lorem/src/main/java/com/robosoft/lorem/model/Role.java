package com.robosoft.lorem.model;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_MERCHANT;
}
