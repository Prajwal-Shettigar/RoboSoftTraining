package com.robosoft.lorem.model;


import lombok.Data;

@Data
public class ItemModel {

    private int dishId;
    private int dishCount;
    private String customizationInfo;
    private int addOnCount;
    private int itemCount;

}
