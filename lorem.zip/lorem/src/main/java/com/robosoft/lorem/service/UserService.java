package com.robosoft.lorem.service;

import com.robosoft.lorem.model.*;

import java.util.List;


public interface UserService {

    RestaurantSearchResult searchRestaurant(SearchFilter searchFilter);

    NearByBrandsSearchResult getNearbyBrands(String address, int limit);

    CartModel saveOrUpdateCart(CartModel cartModel);

    boolean likeAreview(int userId,int reviewId);

    UserProfile getUserProfile(int userId);

    OrderResponseModel getMyOrdersByStatus(String orderStatus, int userId,int pageNumber);

}



