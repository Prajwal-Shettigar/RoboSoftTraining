package com.robosoft.lorem.service;

import com.robosoft.lorem.model.RestaurantSearchModel;
import com.robosoft.lorem.model.SearchFilter;

import java.sql.Date;
import java.util.List;

public interface UserService {

    List<RestaurantSearchModel> searchRestaurant(SearchFilter searchFilter);

}



