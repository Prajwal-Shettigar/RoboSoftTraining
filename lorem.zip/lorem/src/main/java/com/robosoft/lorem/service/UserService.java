package com.robosoft.lorem.service;

import com.robosoft.lorem.model.RestaurantSearchResult;
import com.robosoft.lorem.model.SearchFilter;


public interface UserService {

    RestaurantSearchResult searchRestaurant(SearchFilter searchFilter);

}



